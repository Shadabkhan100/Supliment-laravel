<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeUserMail;
use Illuminate\Support\Facades\Auth;


class AuthController extends Controller
{
    public function registerUser(Request $request)
{
    $request->validate([
        'name' => 'required|string',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:6',
        'phone' => 'nullable',
        'country' => 'nullable',
        'address' => 'nullable',
        'dob' => 'nullable|date',
    ]);

    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
        'phone' => $request->phone,
        'country' => $request->country,
        'address' => $request->address,
        'dob' => $request->dob,
    ]);

    // OPTIONAL: auto login after registration (IMPORTANT PART)
    Auth::login($user);
    $request->session()->regenerate();

    Mail::to($user->email)->send(new WelcomeUserMail($user));

    return response()->json([
        'success' => true,
        'message' => 'User registered successfully and logged in',
        'redirect' => '/'
    ]);
}




public function LoginUser(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required'
    ]);

    if (Auth::attempt([
        'email' => $request->email,
        'password' => $request->password
    ])) {

        $request->session()->regenerate();

        return response()->json([
            'success' => true,
            'message' => 'User logged in successfully.',
            'redirect' => '/'
        ]);
    }

    return response()->json([
        'success' => false,
        'message' => 'Invalid email or password.'
    ], 401);
}

   public function logoutUser(Request $request)
{
    Auth::logout();

    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect('/')
    ->with('success', 'User logged out successfully.');
}
}