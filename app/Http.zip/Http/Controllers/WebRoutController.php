<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CategoriesModel;
use App\Models\SlimzaDeals;
use App\Services\SupabaseStorageService;
use App\Models\ProductsModel;
use Illuminate\Support\Str;
use App\Models\Blogs;

class WebRoutController extends Controller
{
     public function getHome()
    {
        $categories = CategoriesModel::all(); // get all records
        return view('pages.home', compact('categories'));
    }
     public function getAbout()
    {
        return view('about');
    }


public function shopAll()
{
    $products = ProductsModel::all()
        ->map(function ($product) {

            $tags = json_decode($product->tags, true) ?? [];

            return [
                'id' => $product->id,
                'name' => $product->name,
                'description' => $product->description,
                'sku' => $product->sku,
                'price' => $product->price,
                'old_price' => $product->old_price,
                'stock' => $product->stock,
                'category_id' => $product->category_id,
                'deal_id' => $product->deal_id,
                'category_name' => $product->category_name ?? 'Uncategorized',

                // TAGS (raw)
                'tags' => $tags,

                // MAIN IMAGE (Supabase URL)
                'main_image' => $product->main_image
                    ? SupabaseStorageService::getPublicUrl($product->main_image)
                    : null,

                // GALLERY IMAGES (Supabase URLs)
                'gallery_images' => collect(json_decode($product->gallery_images, true) ?? [])
                    ->map(fn ($img) => $img ? SupabaseStorageService::getPublicUrl($img) : null)
                    ->values()
                    ->toArray(),
            ];
        });

    return view('pages.shop-all', compact('products'));
}
 public function getFindProducts($slug, $id)
{
    // FETCH DEAL
    $deal = SlimzaDeals::findOrFail($id);

    // FIX DEAL IMAGE
    $deal->image = $deal->image
        ? SupabaseStorageService::getPublicUrl($deal->image)
        : null;

    // FETCH PRODUCTS RELATED TO THIS DEAL
    $products = ProductsModel::where('deal_id', $id)
        ->latest()
        ->get();

    // FIX PRODUCT IMAGES (IMPORTANT PART)
    $products->transform(function ($product) {
        $product->main_image = $product->main_image
            ? SupabaseStorageService::getPublicUrl($product->main_image)
            : null;

        return $product;
    });

    return view('pages.find-product', compact('deal', 'products'));
}




  public function aboutUsView()
{

    return view('pages.about-us');
}

     public function faqView()
{

    return view('pages.faq');
}
  public function returnView()
{

    return view('pages.policy');
}






public function shippingCost()
    {
        return view('connections.shipping-cost');
    }

    public function thirtyDaysGuarantee()
    {
        return view('connections.30-days-guarantee');
    }

  

    public function privacyPolicy()
    {
        return view('connections.privacy-policy');
    }

public function getProductDetails($slug, $id)
{
    $product = ProductsModel::findOrFail($id);

    $categories = CategoriesModel::pluck('name', 'id');

    $formattedProduct = $this->formatProduct($product, $categories);

    // =========================
    // FIND LOWEST OPTION PRICE (SAFE ARRAY FIX)
    // =========================
    if (
        isset($formattedProduct['options']) &&
        is_array($formattedProduct['options']) &&
        count($formattedProduct['options']) > 0
    ) {

        $prices = array_values(array_filter(array_map(function ($opt) {
            return isset($opt['price']) ? (float) $opt['price'] : null;
        }, $formattedProduct['options'])));

        if (count($prices) > 0) {
            $formattedProduct['price'] = min($prices);
        }
    }

    // =========================
    // FIND MATCHING DEAL (BASED ON PRODUCT deal_id)
    // =========================
    $deal = SlimzaDeals::where('id', $product->deal_id)->first();

    return view('products.product-details', [
        'product' => (object) $formattedProduct,
        'deal' => $deal
    ]);
}

private function formatProduct($product, $categories = null)
{
    $categories = $categories ?? CategoriesModel::pluck('name', 'id');

    // =========================
    // OPTIONS NORMALIZATION
    // =========================
    $options = is_string($product->options)
        ? json_decode($product->options, true)
        : $product->options;

    $options = is_array($options) ? array_values(array_filter($options)) : [];

    // =========================
    // DEFAULT PRICE (DB PRICE)
    // =========================
    $finalPrice = (float) $product->price;

    // =========================
    // OVERRIDE WITH LOWEST OPTION PRICE
    // =========================
    if (count($options) > 0) {

        $prices = array_values(array_filter(array_map(function ($opt) {
            return (isset($opt['price']) && is_numeric($opt['price']))
                ? (float) $opt['price']
                : null;
        }, $options)));

        if (count($prices) > 0) {
            $finalPrice = min($prices);
        }
    }

    return [
        'id' => $product->id,
        'name' => $product->name,
        'description' => $product->description,
        'sku' => $product->sku,

        // FINAL PRICE
        'price' => $finalPrice,
        'old_price' => $product->old_price,

        'stock' => $product->stock,
        'category_id' => $product->category_id,
        'deal_id' => $product->deal_id,

        'category_name' => $categories[$product->category_id] ?? 'Uncategorized',

        'weights' => json_decode($product->weights, true) ?: [],

        // normalized options
        'options' => $options,

        // =========================
        // NEW FIELDS ADDED (SAFE)
        // =========================
        'shipping_info' => $product->shipping_info ?? null,
        'supplement_facts' => $product->supplement_facts ?? null,
        'how_to_use' => $product->how_to_use ?? null,
        'halal_certification' => $product->halal_certification
            ? SupabaseStorageService::getPublicUrl($product->halal_certification)
            : null,

        'main_image' => $product->main_image
            ? SupabaseStorageService::getPublicUrl($product->main_image)
            : null,

        'gallery_images' => collect(json_decode($product->gallery_images, true) ?: [])
            ->filter()
            ->map(fn ($img) => SupabaseStorageService::getPublicUrl($img))
            ->values()
            ->toArray(),
    ];
}



public function searchByTag($tag)
{
    $products = ProductsModel::all()
        ->filter(function ($product) use ($tag) {

            $tags = json_decode($product->tags, true) ?? [];

            $normalizedTags = array_map(function ($t) {
                return Str::slug($t);
            }, $tags);

            return in_array($tag, $normalizedTags);
        })
        ->map(function ($product) {

            $tags = json_decode($product->tags, true) ?? [];

            return [
                'id' => $product->id,
                'name' => $product->name,
                'description' => $product->description,
                'sku' => $product->sku,
                'price' => $product->price,
                'old_price' => $product->old_price,
                'stock' => $product->stock,
                'category_id' => $product->category_id,
                'deal_id' => $product->deal_id,
                'category_name' => $product->category_name ?? 'Uncategorized',

                // ✅ TAGS (keep original + normalized if needed)
                'tags' => $tags,

                // =========================
                // SUPABASE IMAGE URLS
                // =========================
                'main_image' => $product->main_image
                    ? SupabaseStorageService::getPublicUrl($product->main_image)
                    : null,

                'gallery_images' => collect(json_decode($product->gallery_images, true) ?? [])
                    ->map(fn ($img) => $img ? SupabaseStorageService::getPublicUrl($img) : null)
                    ->values()
                    ->toArray(),
            ];
        });

    return view('products.searchProducts', compact('products', 'tag'));
}



      public function getAllBlogs()
    {
        return view('pages.blogs');
    }

 public function contactView()
    {
        return view('pages.contact');
    }

 public function authPage()
    {
        return view('pages.auth');
    }
     

public function shopDetails($slug, $id)
{
     // 1. Get category
    $category = CategoriesModel::findOrFail($id);

    // 2. Convert category image (SUPABASE)
    $category->image = $category->image
        ? SupabaseStorageService::getPublicUrl($category->image)
        : null;

    // 3. Get products under this category
    $products = ProductsModel::where('category_id', $id)->get();

    // 4. Convert product images (SUPABASE)
    $products = $products->map(function ($product) {

        $product->image = $product->main_image
            ? SupabaseStorageService::getPublicUrl($product->main_image)
            : null;

        return $product;
    });
    // 3. Pass slug + products to view
    return view('pages.shop-details', [
        'category_slug' => $slug,
         "category" => $category,
        'products' => $products,
    ]);
}
}
