<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use App\Models\CartModel;
use Illuminate\Support\Facades\Auth;


class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        if (env('APP_ENV') === 'production') {
            URL::forceScheme('https');
        }

        View::composer('*', function ($view) {

    $cartCount = 0;
    $cartTotal = 0;

    $user = Auth::user();

    $currency = session('currency', 'GBP');
    $config = config("currency.currencies.$currency");

    $rate = $config['rate'] ?? 1;
    $symbol = $config['symbol'] ?? '$';

    if ($user) {

        $cartItems = CartModel::where('user_id', $user->id)->get();

        $cartCount = $cartItems->count();

        // IMPORTANT: convert here
        $cartTotal = $cartItems->sum(function ($item) use ($rate) {
            return ($item->price ?? 0) * ($item->quantity ?? 1) * $rate;
        });
    }

    $view->with([
        'cartCount' => $cartCount,
        'cartTotal' => $cartTotal,
        'currencySymbol' => $symbol
    ]);
});

}
}