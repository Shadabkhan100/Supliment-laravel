@extends('layout.Main')

@section('content')
<style>
.shipping-features{
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    text-align: center;
    padding: 15px 10px;
}

.feature-item{
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
}

.feature-item img{
    width: 40px;
    height: 40px;
    object-fit: contain;
}

.feature-item p{
    font-size: 13px;
    margin: 0;
    color: white;
}

/* responsive */
@media (max-width: 350px){
    .shipping-features{
        flex-direction: column;
        gap: 15px;
    }
}
/* ACCORDION HEADER (TITLE AREA) */
#productAccordion .accordion-button {
    background-color: #111;   /* dark background */
    color: #9eef0b;           /* green title */
    font-weight: 600;
    box-shadow: none;
}

/* collapsed state (closed) */
#productAccordion .accordion-button.collapsed {
    background-color: #111;
    color: #9eef0b;
}

/* when active/open */
#productAccordion .accordion-button:not(.collapsed) {
    background-color: #1a1a1a;
    color: #9eef0b;
}

/* remove bootstrap blue border/outline */
#productAccordion .accordion-button:focus {
    box-shadow: none;
    border-color: transparent;
}

/* accordion body (content area) */
#productAccordion .accordion-body {
    background-color: #0d0d0d;
    color: #fff;
}

#productAccordion .accordion-button::after {
    filter: brightness(0) invert(1) sepia(1) hue-rotate(60deg) saturate(5);
}

</style>
<main class="main-wrapper">

    <!-- TITLE BANNER -->
   

    <!-- PRODUCT DETAIL START -->
    <section class="shop-detail-page py-40">
        <div class="container-fluid">
            <div class="detail-wrapper">
                <div class="row row-gap-3">
                    <!-- LEFT IMAGE SECTION -->
                    <div class="col-xl-6">
                        <div class="product-image-container">

                            <!-- THUMB NAV -->
                            <div class="product-slider-asnav">
                                @if(!empty($product->gallery_images))
                                    @foreach($product->gallery_images as $img)
                                        <div class="nav-image">
                                            <img src="{{ $img }}" alt="{{ $product->name }}">
                                        </div>
                                    @endforeach
                                @endif
                            </div>

                            <!-- MAIN SLIDER -->
                            <div class="product-detail-slider">

                                <div class="detail-image">
                                    <img src="{{ $product->main_image }}" alt="{{ $product->name }}">
                                </div>

                                @if(!empty($product->gallery_images))
                                    @foreach($product->gallery_images as $img)
                                        <div class="detail-image">
                                            <img src="{{ $img }}" alt="{{ $product->name }}">
                                        </div>
                                    @endforeach
                                @endif

                            </div>

                        </div>
                    </div>

                    <!-- RIGHT TEXT SECTION -->
                    <div class="col-xl-6">

                        <div class="product-text-container product-text-page">

                            <p class="eyebrow mb-12">
                                {{ $product->category_name }}
                            </p>

                            <h3 class="text-white fw-700 mb-16">
                                {{ $product->name }}
                            </h3>
                             
                            <!-- RATING (static for now) -->
                            <div class="d-flex align-items-center flex-wrap gap-16 mb-16">
                                <h6 class="color-quant">
                                    ★★★★<span class="light-gray">★</span>
                                    <span class="text-16 fw-400 dark-text-white">
                                        ({{ $product->reviews_count ?? 0 }} Reviews)
                                    </span>
                                </h6>
                            </div>
                              
                            <!-- PRICE -->
                         <div class="d-flex align-items-center gap-16 mb-16">

    @if($product->old_price)
        <h6 class="dark-gray text-decoration-line-through old-price">
            {{ number_format($product->old_price, 2) }}
        </h6>
    @endif

    <h4 class="text-white main-price">
        {{ number_format($product->price, 2) }}
    </h4>

</div>
@include("products.buying-options")
                            <!-- DESCRIPTION SHORT -->
                            <p class="quick-view-text mb-16" style="color:white">
                                {{ \Illuminate\Support\Str::limit(strip_tags($product->description), 180) }}
                            </p>
                          
                            <!-- STOCK -->
                            <div class="instock-label color-ter mb-16">
                                {{ $product->stock }} in stock, ready to ship
                            </div>

                            <!-- WEIGHTS -->
                            <h6 class="fw-600 text-white mb-12">Weight</h6>

                            <div class="select-size mb-32">
                                @if(!empty($product->weights))
                                    @foreach($product->weights as $index => $weight)
                                        <input style="color:white" class="hidden radio-label"
                                               type="radio"
                                               name="sizes"
                                               id="weight{{ $index }}"
                                               @if($loop->first) checked @endif>

                                        <label style="color:white" class="button-label" for="weight{{ $index }}">
                                            {{ $weight }} g
                                        </label>
                                    @endforeach
                                @endif
                            </div>

                            <!-- QUANTITY -->
                            <p class="subtitle font-primary fw-600 text-white mb-8">Quantity:</p>

                            <div class="quantity quantity-wrap mb-16" style="color:white;border-color:white">
                                <div class="input-area quantity-wrap" >
                                    <input class="decrement" type="button" value="-" style="color:white" >
                                    <input type="text" name="quantity" value="1" class="number" style="color:white;border-color:white">
                                    <input class="increment" type="button" value="+" style="color:white">
                                </div>
                            </div>

                            <!-- SKU -->
                            <p class="text-white font-primary fw-600 mb-16 h6">
                                SKU:
                                <span class="dark-gray font-sec text-16">
                                    {{ $product->sku }}
                                </span>
                            </p>

                           

                            <!-- FEATURES -->
                            <div  class="d-flex align-items-center gap-12 mb-16">
                                <p style="color:white">90 day returns policy</p>
                            </div>

                            <div class="d-flex align-items-center gap-12 mb-16">
                                <p style="color:white">Free shipping on eligible orders</p>
                            </div>




                    


                           <!-- BUTTONS -->
                            <div class="row row-gap-3 mb-16 mt-4">
                                <div class="col-sm-6">
                                    <a href="javascript:;"
                                       class="cus-btn-2 text-center w-100 cart-button22"
                                       data-id="{{ $product->id }}">
                                        Add to Cart
                                    </a>
                                </div>

                                <div class="col-sm-6">
                                    <a href="javascript:;"
                                       class="cus-btn text-center w-100">
                                        Buy It Now
                                    </a>
                                </div>

                            </div>

<div class="shipping-features">
    <div class="feature-item">
        <img src="/images/icons/delivery.png" alt="">
        <p>Next Day Delivery (12pm cut-off)</p>
    </div>

    <div class="feature-item">
        <img src="/images/icons/parcel.png" alt="">
        <p>Royal Mail Tracked 24H Shipping</p>
    </div>

    <div class="feature-item">
        <img src="/images/icons/guarantee.png" alt="">
        <p>30-Day Money Back Guarantee</p>
    </div>
</div>
                       <!-- PRODUCT EXTRA DETAILS ACCORDION -->
<div class="accordion mt-3" id="productAccordion">

    <!-- DESCRIPTION -->
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingDesc">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseDesc">
                Description
            </button>
        </h2>
        <div id="collapseDesc" class="accordion-collapse collapse show" data-bs-parent="#productAccordion">
            <div class="accordion-body">
                {!! $product->description !!}
            </div>
        </div>
    </div>

    <!-- SHIPPING INFO -->
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingShip">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseShip">
                Shipping Info
            </button>
        </h2>
        <div id="collapseShip" class="accordion-collapse collapse" data-bs-parent="#productAccordion">
            <div class="accordion-body">
                {{ $product->shipping_info }}
            </div>
        </div>
    </div>

    <!-- SUPPLEMENT FACTS -->
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingSupp">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSupp">
                Supplement Facts
            </button>
        </h2>
        <div id="collapseSupp" class="accordion-collapse collapse" data-bs-parent="#productAccordion">
            <div class="accordion-body">
                {{ $product->supplement_facts }}
            </div>
        </div>
    </div>

    <!-- HOW TO USE -->
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingUse">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseUse">
                How to Use
            </button>
        </h2>
        <div id="collapseUse" class="accordion-collapse collapse" data-bs-parent="#productAccordion">
            <div class="accordion-body">
                {{ $product->how_to_use }}
            </div>
        </div>
    </div>

    <!-- HALAL CERTIFICATION -->
    @if(!empty($product->halal_certification))
    <div class="accordion-item">
        <h2 class="accordion-header" id="headingHalal">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseHalal">
                Halal Certification
            </button>
        </h2>
        <div id="collapseHalal" class="accordion-collapse collapse" data-bs-parent="#productAccordion">
    <div class="accordion-body">

        <img src="{{ $product->halal_certification }}"
             style="
                width: 100%;
                max-width: 100%;
                height: 300px;
                object-fit: contain;
                border-radius: 12px;
                background: #fff;
             ">

    </div>
</div>
    </div>
    @endif

</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- DESCRIPTION + REVIEWS -->
  

</main>
<script>
window.currencyConfig = @json(config('currency'));
window.currentCurrency = "{{ session('currency', 'GBP') }}";

function formatPrice(value) {
    const currency = window.currentCurrency || window.currencyConfig.default || "GBP";
    const config = window.currencyConfig?.currencies?.[currency];
 console.log("Currency:", currency);
    console.log("Config found:", config);
    console.log("Symbol:", config?.symbol);
      if (!config) return value;

    const converted = value * config.rate;

    return `${config.symbol} ${converted.toFixed(2)}`;
}

function getNumber(text) {
    return parseFloat(text.replace(/[^0-9.]/g, ''));
}

document.addEventListener('DOMContentLoaded', function () {

    // MAIN PRICE
    document.querySelectorAll('.main-price').forEach(el => {
        const value = getNumber(el.innerText);
        if (!isNaN(value)) {
            el.innerText = formatPrice(value);
        }
    });

    // OLD PRICE
    document.querySelectorAll('.old-price').forEach(el => {
        const value = getNumber(el.innerText);
        if (!isNaN(value)) {
            el.innerText = formatPrice(value);
        }
    });

});

document.querySelector('.cart-button22').addEventListener('click', function () {

    const productId = this.dataset.id;

    if (!window.selectedOption) {
        alert("Please select a buying option first");
        return;
    }

    const payload = {
        product_id: productId,
        option: window.selectedOption,
        purchase_type: window.purchaseMode || "one_time",
        quantity: document.querySelector('input[name="quantity"]').value
    };

    console.log("ADDING TO CART:");
    console.log(payload);

    // Example AJAX (if needed)
   fetch('/cart/add', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': '{{ csrf_token() }}'
    },
    body: JSON.stringify(payload)
})
.then(async res => {

    const data = await res.json();

    // ❌ NOT LOGGED IN
    if (res.status === 401) {

        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'error',
            title: data.message,
            showConfirmButton: false,
            timer: 6000,
            timerProgressBar: true
        });

      


    }

    // ✅ SUCCESS
    if (data.status) {

        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: data.message,
            showConfirmButton: false,
            timer: 6000,
            timerProgressBar: true
        });

    } else {

        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'error',
            title: data.message || "Something went wrong",
            showConfirmButton: false,
            timer: 6000,
            timerProgressBar: true
        });
    }

})
.catch(() => {
    Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'error',
        title: "Server error occurred",
        showConfirmButton: false,
        timer: 6000,
        timerProgressBar: true
    });
});

});

</script>
@include("modules.you-may-like")
@endsection