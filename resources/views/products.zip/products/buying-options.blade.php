<style>
.option-box {
    border: 1px solid #ddd;
    transition: 0.2s ease-in-out;
}

.option-box.option-selected {
    border: 2px solid #9eef0b !important;
    box-shadow: 0 0 10px rgba(158, 239, 11, 0.3);
    transform: scale(1.01);
}

.purchase-card {
    border: 2px solid #ddd;
    padding: 15px;
    border-radius: 10px;
    cursor: pointer;
    transition: 0.2s ease-in-out;
}

.purchase-card.active {
    border: 2px solid #9eef0b;
    box-shadow: 0 0 10px rgba(158, 239, 11, 0.3);
}
.option-box {
    position: relative;
}

/* BADGE STYLE */
.option-badge {
    position: absolute;
    top: 10px;
    right: 10px;

    background: linear-gradient(135deg, #9eef0b, #7ad600);
    color: #000;

    font-size: 11px;
    font-weight: 600;

    padding: 4px 10px;
    border-radius: 20px;

    box-shadow: 0 4px 10px rgba(0,0,0,0.15);

    z-index: 10;
    white-space: nowrap;
}
</style>

@php
    $defaultDiscount = 20; // subscribe discount
@endphp

<!-- ================= PURCHASE TYPE CARDS ================= -->
<div class="row g-3 mb-3">

    <div class="col-6">
        <div class="purchase-card active w-100" id="oneTimeCard">
            <div class="fw-bold">One Time Purchase</div>
            <div class="text-muted small">Pay once for your order</div>
        </div>
    </div>

    <div class="col-6">
        <div class="purchase-card w-100" id="subscribeCard">
            <div class="fw-bold">Subscribe & Save</div>
            <div class="text-success small">Save {{ $defaultDiscount }}% on every order</div>
        </div>
    </div>

</div>

<input type="hidden" id="purchaseType" value="one_time">

<!-- ================= PACK OPTIONS ================= -->
<div class="row g-3">

@if(!empty($product->options) && is_array($product->options))

    @foreach($product->options as $opt)

        @php
            $pack = (int) ($opt['pack'] ?? 1);
            $price = (float) ($opt['price'] ?? 0);
            $discount = (float) ($opt['discount'] ?? 0);

            $basePrice = $discount > 0
                ? $price - ($price * $discount / 100)
                : $price;
        @endphp

        <div class="col-md-6">

            <div class="d-flex border rounded p-3 align-items-center gap-3 option-box"
                       data-price="{{ $basePrice }}"
                       data-base-price="{{ $basePrice }}"
                       data-option='@json($opt)'
                      style="cursor:pointer;"> 
                    
                <!-- IMAGE -->
                <div style="width:80px;height:80px;flex-shrink:0;overflow:hidden;border-radius:10px;background:#f5f5f5;display:flex;align-items:center;justify-content:center;">
                    <img src="{{ $opt['image'] ?? '/placeholder.png' }}"
                         style="width:100%;height:100%;object-fit:cover;">
                </div>

                <!-- CONTENT -->
                <div class="flex-grow-1">

                    <div class="fw-bold">
                        {{ $pack }} x Pack
                    </div>

                    <div class="mt-1">
                        <span class="badge bg-light text-dark border per-pouch">
                            £{{ number_format($basePrice / max($pack,1), 2) }} per pouch
                        </span>
                    </div>

                    <div class="text-muted small mt-2">
                        {{ $opt['duration'] ?? '' }} Days
                    </div>

                </div>

                <!-- PRICE -->
                <div class="fw-bold fs-5 price-box">
                    £{{ number_format($basePrice, 2) }}
                </div>
                 <div class="option-badge">
                  🎁 Get Free {{ $pack }} Pack
                 </div>
            </div>
           
        </div>

    @endforeach

@else

    <div class="col-12 text-muted">
        No pack options available
    </div>

@endif

</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

    let discount = {{ $defaultDiscount }};

    const oneTimeCard = document.getElementById("oneTimeCard");
    const subscribeCard = document.getElementById("subscribeCard");
    const purchaseType = document.getElementById("purchaseType");

    const optionBoxes = document.querySelectorAll(".option-box");

    window.selectedOption = null;
    window.purchaseMode = "one_time";

    // =========================
    // CURRENCY CONFIG
    // =========================
    window.currencyConfig = @json(config('currency'));
    window.currentCurrency = "{{ session('currency', 'GBP') }}";

    function formatPrice(price) {

        const currency = window.currentCurrency || window.currencyConfig.default || "GBP";
        const config = window.currencyConfig?.currencies?.[currency];

        if (!config) {
            return `£ ${price}`;
        }

        const converted = price * config.rate;
        return `${config.symbol} ${converted.toFixed(2)}`;
    }

    // =========================
    // UPDATE OPTION PRICES
    // =========================
    function updatePrices(type) {

        optionBoxes.forEach(box => {

            let basePrice = parseFloat(box.dataset.basePrice);
            let pack = parseInt(
                box.querySelector(".fw-bold").innerText.replace(/\D/g, '')
            ) || 1;

            let finalPrice = basePrice;

            // subscribe discount (applied BEFORE currency conversion)
            if (type === "subscribe") {
                finalPrice = basePrice - (basePrice * discount / 100);
            }

            let perPouch = finalPrice / pack;

            // IMPORTANT: convert using currency function
            box.querySelector(".price-box").innerText =
                formatPrice(finalPrice);

            box.querySelector(".per-pouch").innerText =
                formatPrice(perPouch) + " per pouch";
        });
    }

    // =========================
    // BUY MODE SWITCH
    // =========================
    oneTimeCard.addEventListener("click", function () {

        oneTimeCard.classList.add("active");
        subscribeCard.classList.remove("active");

        window.purchaseMode = "one_time";
        purchaseType.value = "one_time";

        updatePrices("one_time");
    });

    subscribeCard.addEventListener("click", function () {

        subscribeCard.classList.add("active");
        oneTimeCard.classList.remove("active");

        window.purchaseMode = "subscribe";
        purchaseType.value = "subscribe";

        updatePrices("subscribe");
    });

    // =========================
    // OPTION SELECTION
    // =========================
    optionBoxes.forEach(box => {

    box.addEventListener("click", function () {

        optionBoxes.forEach(b => b.classList.remove("option-selected"));
        this.classList.add("option-selected");

        const opt = JSON.parse(this.dataset.option);
        const basePrice = parseFloat(this.dataset.basePrice);

        let pack = parseInt(
            this.querySelector(".fw-bold").innerText.replace(/\D/g, '')
        ) || 1;

        // apply subscribe discount if needed
        let finalPrice = basePrice;

        if (window.purchaseMode === "subscribe") {
            finalPrice = basePrice - (basePrice * discount / 100);
        }

        // store globally for product page
        window.selectedOption = opt;
        window.selectedOption.finalPrice = finalPrice;
        window.selectedOption.pack = pack;

        // 🔥 UPDATE MAIN PRICE LIVE
        updateMainPrice(finalPrice);

        console.log("Selected option:", window.selectedOption);
    });

});

    // =========================
    // AUTO SELECT LOWEST PRICE
    // =========================
    let lowestBox = null;
    let lowestPrice = Infinity;

    optionBoxes.forEach(box => {

        let price = parseFloat(box.dataset.basePrice);

        if (!isNaN(price) && price < lowestPrice) {
            lowestPrice = price;
            lowestBox = box;
        }
    });

    if (lowestBox) {

        lowestBox.classList.add("option-selected");

        window.selectedOption = JSON.parse(lowestBox.dataset.option);

        console.log("Default lowest option selected:", window.selectedOption);
    }

    // INITIAL LOAD
    updatePrices("one_time");

});

function updateMainPrice(price) {
    const mainPriceEl = document.querySelector('.main-price');

    if (!mainPriceEl) return;

    mainPriceEl.innerText = formatPrice(price);
}
</script>