<!doctype html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Category Management</title>

<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">

<script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
<script src="{{ asset('js/bootstrap.min.js') }}"></script>

<style>
body{
    background:#f4f6f9;
    font-family:Arial;
}

.page-card{
    background:#fff;
    border-radius:20px;
    padding:30px;
    box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.table img{
    width:60px;
    height:60px;
    object-fit:cover;
    border-radius:12px;
}

.preview-image{
    width:120px;
    height:120px;
    object-fit:cover;
    border-radius:12px;
    margin-top:10px;
    display:none;
}

.table thead{
    background:#111;
    color:#fff;
}
</style>

</head>

<body>

<div class="container py-5">

<div class="page-card">

<!-- HEADER -->
<div class="d-flex justify-content-between mb-4">

    <div>
        <h3>Category Management</h3>
        <p class="text-muted">Manage categories</p>
    </div>

    <button class="btn btn-dark" onclick="openAddModal()">
        + Add Category
    </button>

</div>

<!-- TABLE -->
<table class="table table-bordered align-middle">

<thead>
<tr>
    <th>#</th>
    <th>Image</th>
    <th>Name</th>
   
    <th>Products</th>
    <th>Action</th>
</tr>
</thead>

<tbody id="categoryTableBody"></tbody>

</table>

</div>
</div>

<!-- ================= MODAL ================= -->
<div class="modal fade" id="categoryModal" tabindex="-1">
<div class="modal-dialog">

<div class="modal-content">

<div class="modal-header">
<h5 id="modalTitle">Add Category</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<form id="categoryForm" enctype="multipart/form-data">

@csrf

<input type="hidden" id="category_id">

<div class="mb-2">
<label>Name</label>
<input type="text" id="edit_name" name="name" class="form-control">
</div>



<div class="mb-2">
<label>Image</label>
<input type="file" id="edit_image" name="image" class="form-control">

<img id="edit_preview" class="preview-image">
</div>

<button class="btn btn-dark w-100" id="submitBtn">
Save
</button>

</form>

</div>

</div>
</div>
</div>

<script>

let modal = new bootstrap.Modal(document.getElementById('categoryModal'));

/* ================= LOAD ================= */
function loadCategories()
{
$.get('/api/categories', function(res){

let data = res.data;

$('#categoryTableBody').html('');

data.forEach((c,i)=>{

$('#categoryTableBody').append(`
<tr>
<td>${i+1}</td>
<td><img src="${c.image}"></td>
<td>${c.name}</td>

<td>${c.products_count}</td>
<td>
<button class="btn btn-warning btn-sm" onclick='editCategory(${JSON.stringify(c)})'>Edit</button>
<button class="btn btn-danger btn-sm" onclick="deleteCategory(${c.id})">Delete</button>
</td>
</tr>
`);
});

});
}

/* ================= ADD MODAL ================= */
function openAddModal()
{
$('#categoryForm')[0].reset();
$('#category_id').val('');
$('#edit_preview').hide();
$('#modalTitle').text('Add Category');
$('#submitBtn').text('Save');

modal.show();
}

/* ================= EDIT ================= */
function editCategory(c)
{
$('#category_id').val(c.id);
$('#edit_name').val(c.name);
$('#edit_index_no').val(c.index_no);

$('#modalTitle').text('Edit Category');
$('#submitBtn').text('Update');

if(c.image){
$('#edit_preview').show().attr('src',c.image);
}

modal.show();
}

/* ================= IMAGE PREVIEW ================= */
$('#edit_image').change(function(e){

let file = e.target.files[0];

if(file){
$('#edit_preview').show().attr('src',URL.createObjectURL(file));
}

});

/* ================= SUBMIT (CREATE + UPDATE) ================= */
$('#categoryForm').submit(function(e){

e.preventDefault();

let formData = new FormData(this);
let id = $('#category_id').val();

let url = id
? `/api/edit-category/${id}`
: `/api/create-category`;

$.ajax({
url:url,
type:'POST',
data:formData,
processData:false,
contentType:false,

success:function(){
modal.hide();
loadCategories();
},

error: function (err) {

    console.log(err.responseJSON);

    let message = "Something went wrong";

    if (err.responseJSON) {

        // Laravel validation errors
        if (err.responseJSON.errors) {
            let errors = err.responseJSON.errors;

            message = Object.values(errors)
                .map(e => e[0])
                .join('\n');
        }

        // Custom message from backend
        else if (err.responseJSON.message) {
            message = err.responseJSON.message;
        }
    }

    alert(message);
}
});

});

/* ================= DELETE ================= */
function deleteCategory(id)
{
if(!confirm('Delete?')) return;

$.ajax({
url:'/api/delete-category/'+id,
type:'DELETE',
data:{_token:'{{ csrf_token() }}'},
success:function(){
loadCategories();
}
});
}

/* ================= INIT ================= */
loadCategories();

</script>

</body>
</html>